// Écrivez une boucle for qui affiche les nombres de 1 à 10 dans la console.
for(let i=1; i<=10; i++){
    console.log(i);
};

// Écrivez une boucle while qui affiche les nombres de 10 à 1 dans la console.
let ind = 10;
while (ind >=1) {
    console.log(ind);
    ind--
};

// Écrivez une boucle do...while qui affiche les nombres pairs de 2 à 20 dans la console.
let pair = 2;
do {
    console.log(pair);
    pair += 2;
} while (pair <= 20);

// Écrivez une boucle for...of qui affiche chaque élément d'un tableau de mots (par exemple, ["un", "deux", "trois"]).
let tab = ["un", "deux", "trois"];
for(e of tab){
    console.log(e);
};

// Écrivez une boucle for qui calcule la somme des nombres de 1 à 10 et affiche le résultat dans la console.
let compteur = 0;
for(let i=1; i<= 10; i++){
    compteur += i;
    console.log(compteur)
};

// Écrivez une boucle while qui demande à l'utilisateur de saisir un nombre jusqu'à ce qu'il saisisse un nombre positif.
let nbr;
while (nbr  != Math.abs(nbr)) {
    nbr = prompt("Entrez un nombre");
};

// Écrivez une boucle for qui affiche les nombres de 1 à 10 en utilisant l'instruction break pour sortir de la boucle lorsque le nombre atteint 5.
for (let i = 0; i <= 10; i++) {
    console.log(i)
    if(i == 5){
        break;
    }    
};

// Écrivez une boucle for qui affiche les nombres de 1 à 10 en utilisant l'instruction continue pour passer à l'itération suivante lorsque le nombre est pair.
for (let i = 1; i <= 10; i++) {
    if (i%2 == 0){
        continue;
    }
    console.log(i);
};

// Ecrire un programme qui demande à l'ulisateur d'introduire 10 nombres
// eners. Ces nombres sont enregistrés dans un tableau.
// Le programme demande ensuite à l'ulisateur quel nombre il cherche. Si
// ce nombre est présent dans le tableau, le programme affiche l'indice de
// ce nombre dans le tableau.
let tabEnt = [];
for (let i = 1; i <= 10; i++) {
    tabEnt.push(prompt(`Entrez le nombre: numero ${i}`));
};
let search = prompt("Quel nombre vous cherchez");
console.log(tabEnt);
tabEnt.forEach(element => {
    if (search == element) {
        alert(`L'index de ce nombre est ${tabEnt.indexOf(element)}`);
    };
});